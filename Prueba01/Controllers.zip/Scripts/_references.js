﻿
/// <reference path="jquery-1.11.2.js"/>
/// <reference name="MicrosoftAjax.js" />
/// <reference path="daf-resources.js"/>
/// <reference path="daf.js"/>
/// <reference path="daf-menu.js"/>
/// <reference path="touch.js"/>
/// <reference path="touch-charts.js"/>
/// <reference path="..\touch\jquery.mobile-1.4.5.js"/>
