﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Datos
{
    class conexion
    {
        private string CadConexion = "Data Source=54.187.223.208;Initial Catalog=sw2;Persist Security Info=True;User ID=sa;Password=Escalante123";
            ///"workstation id=generar.mssql.somee.com;packet size=4096;user id=gear_soft_SQLLogin_1;pwd=gyt2fnyc6e;data source=generar.mssql.somee.com;persist security info=False;initial catalog=generar";

        SqlCommand cmd;
        SqlConnection con;

        public conexion()
        {
            con = new SqlConnection(CadConexion);
        }

        public void crearComando(string cad)
        {
            con.ConnectionString = CadConexion;
            cmd = new SqlCommand(cad, con);
        }

        public string CadenaConexion()
        {
            SqlConnectionStringBuilder csb = new SqlConnectionStringBuilder();
            csb.DataSource = @"(local)";// @"TOSHIBA-PC";
            csb.InitialCatalog = "generar";
            csb.IntegratedSecurity = true;

            return csb.ConnectionString;
        }

        public void AdicionarParametro(string parametro, object valor)
        {
            cmd.Parameters.AddWithValue(parametro, valor);
        }

      

        public void Insert()
        {
            using (con)
            {
                con.Open();
                cmd.ExecuteScalar();
                con.Close();
            }
        }

      
    }
}
