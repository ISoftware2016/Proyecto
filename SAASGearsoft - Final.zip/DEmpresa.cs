﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Datos
{
    public class DEmpresa
    {
        public string NombreTabla = "Empresa";
        private conexion con = new conexion();
        /*
   	id int identity(1,1) primary key, 
	Nombre VARCHAR(300) NOT NULL,	
	Correo VARCHAR(300) NOT NULL,	
	Pass VARCHAR(300) NOT NULL	
         */
        public void Insert(string nombre, string correo, string pass)
        {
            string Sql;
            Sql = "INSERT INTO " + NombreTabla +
                "(Nombre,Correo,Pass) " +
                "VALUES " + "(@Nombre, @Correo, @Pass) " +
                "SELECT @@Identity";
            con.crearComando(Sql);

            con.AdicionarParametro("@Nombre", nombre);
            con.AdicionarParametro("@Correo", correo);
            con.AdicionarParametro("@Pass", pass);

            con.Insert();
        }

     
    }
}
