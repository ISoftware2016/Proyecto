﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos;
using System.Data;

namespace Negocio
{
    public class NEmpresa
    {
        private DEmpresa objDEmpresa = new DEmpresa();


        public void Insert(string nombre, string correo, string pass)
        {
            objDEmpresa.Insert(nombre, correo, pass);
        }
      

    }
}
