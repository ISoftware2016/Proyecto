﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using Negocio;

namespace SAASGearsoft
{
    public partial class index : System.Web.UI.Page
    {
        NEmpresa ObjEmpresa;
        protected void Page_Load(object sender, EventArgs e)
        {
                ObjEmpresa = new NEmpresa();
        }

        protected void Btn_Registrar(object sender, EventArgs e)
        {
            String TEXTO = "";
            System.Net.Mail.MailMessage correo = new System.Net.Mail.MailMessage();
            correo.From = new System.Net.Mail.MailAddress("gear_soft@hotmail.com");
            correo.To.Add(txt_email.Text);
            correo.Subject = "Credenciales By GearSoft";
            TEXTO += "\n\nFecha y hora GMT: " +
                DateTime.Now.ToUniversalTime().ToString("dd/MM/yyyy HH:mm:ss") + "\n\n El nombre de su empresa es : " + txt_nombre.Text
                + "\n Su usuario es : " + txt_email.Text + "\n Su Contraseña es : " + txt_passwrd.Text;
            correo.Body = TEXTO;
            correo.IsBodyHtml = false;
            correo.Priority = System.Net.Mail.MailPriority.Normal;
            //
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            //
            //---------------------------------------------
            // Estos datos debes rellanarlos correctamente
            //---------------------------------------------
            smtp.Host = "smtp.live.com";
            smtp.Credentials = new System.Net.NetworkCredential("gear_soft@hotmail.com", "gearsoft2016");
            smtp.EnableSsl = true;
            try
            {
             //   smtp.Send(correo);
                ObjEmpresa.Insert(txt_nombre.Text, txt_email.Text, txt_passwrd.Text);
                Mensaje("Mensaje enviado satisfactoriamente");
            }
            catch (Exception ex)
            {
                Mensaje("ERROR: " + ex.Message);
            }
        }
        void Mensaje(String sms)
        {
            this.Page.Response.Write("<script language='JavaScript'>window.alert('" + sms + "');</script>");
        }
    }
}